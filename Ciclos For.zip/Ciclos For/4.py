import os
os.system('cls')

print("Números pares hasta el 100:")
print("-" * 30)

for i in range(0, 101, 2):
    print(i)
