import os  
os.system('cls')

suma = 0

for i in range(100, 201):
    suma += i

print(f"La suma de los números del 100 al 200 es: {suma}")
