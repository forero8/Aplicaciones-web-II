import os
os.system('cls')

numero = 5
print(f"Tabla de multiplicar del {numero}")
print("-" * 30)

for i in range(1, 11):
    resultado = numero * i
    print(f"{numero} x {i} = {resultado}")
