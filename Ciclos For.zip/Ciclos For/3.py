import os
os.system('cls')

for i in range(1000, 499, -1):
    print(i)
