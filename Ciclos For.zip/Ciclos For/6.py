import os
os.system('cls')

print("Serie de Fibonacci (primeros 10 términos):")
print("-" * 30)

a, b = 0, 1

for i in range(10):
    print(a)
    a, b = b, a + b
