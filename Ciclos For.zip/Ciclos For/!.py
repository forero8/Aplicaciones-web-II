import os
os.system('cls')

for i in range(101):
    print(i)
