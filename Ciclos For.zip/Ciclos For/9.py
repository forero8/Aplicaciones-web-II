import os
os.system('cls')

primos = []

for num in range(2, 101):
    es_primo = True
    
    for divisor in range(2, int(num ** 0.5) + 1):
        if num % divisor == 0:
            es_primo = False
            break
    
    if es_primo:
        primos.append(num)

print("Números primos entre 0 y 100:")
print("-" * 40)
print(primos)
print("-" * 40)
print(f"Total de números primos: {len(primos)}")
 