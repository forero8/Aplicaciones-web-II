import os
os.system("cls")

def analizar_numeros(*args, **kwargs):
    mostrar_pares = kwargs.get("mostrar_pares", True)
    mostrar_impares = kwargs.get("mostrar_impares", True)
    
    pares = []
    impares = []
    
    for numero in args:
        if numero % 2 == 0:
            pares.append(numero)
        else:
            impares.append(numero)
    if mostrar_pares:
        pares_str = ", ".join(map(str, pares))
        print(f"Números pares mi pelao: {pares_str if pares_str else 'Ninguno'} (Total: {len(pares)})")
    
    if mostrar_impares:
        impares_str = ", ".join(map(str, impares))
        print(f"Números impares mi pelao: {impares_str if impares_str else 'Ninguno'} (Total: {len(impares)})")
    
    print(f"\nTotal de números analizados mi pelao: {len(args)}")

try:
    print("Aqui analizo los numeros mi pelao\n")
    
    entrada = input("Pon los números separados por espacios mi pelao: ")
    numeros = list(map(int, entrada.split()))
    
    print("\n¿Qué quieres ver mi pelao?")
    opcion_pares = input("¿Mostrar pares? (S/N, por defecto S): ").upper()
    opcion_impares = input("¿Mostrar impares? (S/N, por defecto S): ").upper()
    
    mostrar_pares = opcion_pares != "N"
    mostrar_impares = opcion_impares != "N"
    
    print("\n" + "="*40)
    analizar_numeros(*numeros, mostrar_pares=mostrar_pares, mostrar_impares=mostrar_impares)
    print("="*40)
    
except ValueError:
    print("Error: Debe ingresar números enteros separados por espacios mi pelao.")
except Exception as e:
    print(f"Error: {e}")