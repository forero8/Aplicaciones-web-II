import os
os.system("cls")

def calcular_impuesto(valor, impuesto=19):
    return valor + (valor * impuesto / 100)

try:
    print("=== Cálculo de Impuestos ===\n")
    
    total_con_impuesto = 0
    total_sin_impuesto = 0
    cantidad_productos = 0
    
    while cantidad_productos < 3:
        try:
            valor = float(input(f"Ingrese el precio del producto {cantidad_productos + 1}: $"))
            
            if valor < 0:
                print("Por favor, ingrese un valor positivo mi pelao.\n")
                continue
            
            valor_final = calcular_impuesto(valor)
            
            print(f"  Valor sin impuesto mi pelao: ${valor:.2f}")
            print(f"  Valor con impuesto mi pelao (19%): ${valor_final:.2f}\n")
            
            total_sin_impuesto += valor
            total_con_impuesto += valor_final
            cantidad_productos += 1
            
        except ValueError:
            print("Error: ingrese un precio válido mi pelao.\n")
    
    print("=" * 35)
    print(f"Total sin impuesto mi pelao: ${total_sin_impuesto:.2f}")
    print(f"Total con impuesto mi pelao: ${total_con_impuesto:.2f}")
    print(f"Impuesto total pagado mi pelao: ${total_con_impuesto - total_sin_impuesto:.2f}")
    print("=" * 35)

except Exception as e:
    print(f"Error: {e}")