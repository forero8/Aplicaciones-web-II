import os
os.system("cls")

try:
    n = int(input("Pon un número entero positivo mi pelao: "))

    if n > 0:
        tabla_mas_larga = 0
        numero_tabla_mas_larga = 0

        for i in range(1, n + 1):
            print("\nTabla del", i)
            contador = 0

            for j in range(1, n + 1):
                print(i, "x", j, "=", i * j)
                contador += 1

            if contador > tabla_mas_larga:
                tabla_mas_larga = contador
                numero_tabla_mas_larga = i

        print("\nLa tabla más larga generada fue la del número", numero_tabla_mas_larga, "con", tabla_mas_larga, "multiplicaciones")

    else:
        print("Pon un número positivo mi pelao")

except:
    print("Error: debes de poner un número entero mi pelao")