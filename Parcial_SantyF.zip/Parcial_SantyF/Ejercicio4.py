import os
os.system("cls")

print("MI cajero automatico mi pelao\n")

try:
    try:
        saldo_inicial = int(input("Ingrese el saldo inicial: $"))
        if saldo_inicial < 0:
            print("Error: El saldo inicial no puede ser negativo.")
            exit()
    except ValueError:
        print("Error: Debe ingresar un número entero válido para el saldo.")
        exit()
    
    print(f"Saldo actual: ${saldo_inicial}\n")
    
    try:
        monto_retirar = int(input("Ingrese el monto a retirar: $"))
    except ValueError:
        print("Error: Debe ingresar un número válido.")
        exit()
    
    if monto_retirar < 0:
        print("Error: No se permiten valores negativos.")
    
    elif monto_retirar > saldo_inicial:
        print("Error: Fondos insuficientes.")
        print(f"Intenta retirar: ${monto_retirar}")
        print(f"Saldo disponible: ${saldo_inicial}")
    

    else:
        saldo_final = saldo_inicial - monto_retirar
        print(f"\n✓ Retiro exitoso")
        print(f"Monto retirado: ${monto_retirar}")
        print(f"Saldo anterior: ${saldo_inicial}")
        print(f"Saldo actual: ${saldo_final}")

except Exception as e:
    print(f"Error inesperado: {e}")