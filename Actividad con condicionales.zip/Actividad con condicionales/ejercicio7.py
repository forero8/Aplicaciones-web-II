import os;
os.system("cls")

dia = int(input("Ingresa el día: "))
mes = int(input("Ingresa el mes: "))
anio = int(input("Ingresa el año: "))

dias_por_mes = {
    1: 31,
    2: 28,
    3: 31,   
    4: 30,   
    5: 31,
    6: 30,   
    7: 31,   
    8: 31,        
    9: 30,
    10: 31,
    11: 30,
    12: 31  
}

if mes < 0 or mes > 12:
    print(f"La fecha {dia}/{mes}/{anio} es incorrecta (mes inválido)")

elif anio <= 0:
    print(f"La fecha {dia}/{mes}/{anio} es incorrecta (año inválido)")

elif dia < 1 or dia > dias_por_mes[mes]:
    print(f"La fecha {dia}/{mes}/{anio} es incorrecta (día inválido para el mes)")
else:
    print(f"La fecha {dia}/{mes}/{anio} es correcta")
