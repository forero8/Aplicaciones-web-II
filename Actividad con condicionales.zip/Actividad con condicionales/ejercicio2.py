import os;
os.system("cls")

numero1 = float(input("Pon el primer número mi pelao: "))
numero2 = float(input("pon el segundo numero mi pelao: "))

if numero1 == numero2:
    print("Los números son iguales mi pelao")
else:
    print("Los números no son iguales mi pelao")
