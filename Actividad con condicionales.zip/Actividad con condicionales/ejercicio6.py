import os;
os.system("cls")

dia = int(input("Ingresa el día: "))
mes = int(input("Ingresa el mes: "))
anio = int(input("Ingresa el año: "))

if dia >= 1 and dia <= 30 and mes >= 1 and mes <= 12 and anio > 0:
    print(f"La fecha {dia}/{mes}/{anio} es correcta")
else:
    print(f"La fecha {dia}/{mes}/{anio} es incorrecta")
