import os;
os.system("cls")

numero = int(input("Ingresa un número de tres cifras: "))

if numero < 100 or numero > 999:
    print("El número debe tener exactamente tres cifras")
else:
    numero_str = str(numero)
    numero_invertido = numero_str[::-1]
    
    if numero_str == numero_invertido:
        print(f"El número {numero} es capicúa")
    else:
        print(f"El número {numero} no es capicúa")
        print(f"Al revés sería: {numero_invertido}")
