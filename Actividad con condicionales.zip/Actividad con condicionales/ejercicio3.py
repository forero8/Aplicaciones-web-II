import os;
os.system("cls")
numero1 = int(input("Ingresa el primer número: "))
numero2 = int(input("Ingresa el segundo número: "))

if numero1 % numero2 == 0:
    print(f"{numero1} es múltiplo de {numero2}")
elif numero2 % numero1 == 0:
    print(f"{numero2} es múltiplo de {numero1}")
else:
    print("Ninguno es múltiplo del otro")
