import os;
os.system("cls")       


compra = float(input("Ingresa el monto de la compra: "))

if compra > 300000:
    descuento = compra * 0.20
    monto_pagar = compra - descuento
    print(f"Monto de la compra: {compra:,.2f}")
    print(f"Descuento del 20%: {descuento:,.2f}")
    print(f"Monto a pagar: {monto_pagar:,.2f}")
else:
    print(f"Monto de la compra: {compra:,.2f}")
    print(f"Monto a pagar: {compra:,.2f} (sin descuento)")
