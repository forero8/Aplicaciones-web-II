import os;
os.system("cls")

numero1 = float(input("Ingresa el primer número: "))
numero2 = float(input("Ingresa el segundo número: "))
numero3 = float(input("Ingresa el tercer número: "))

numeros = [numero1, numero2, numero3]
numeros_ordenados = sorted(numeros, reverse=True)

print(f"Los números ordenados de mayor a menor son: {numeros_ordenados}")
