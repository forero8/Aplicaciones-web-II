import os;
os.system("cls")   

nota = int(input("Ingresa una nota entre 0 y 10: "))

notas_texto = {
    0: "cero",
    1: "uno",
    2: "dos",
    3: "tres",
    4: "cuatro",
    5: "cinco",
    6: "seis",
    7: "siete",
    8: "ocho",
    9: "nueve",
    10: "diez"
}

if nota < 0 or nota > 10:
    print("La nota debe estar entre 0 y 10")
else:
    print(f"La nota es: {notas_texto[nota]}")
