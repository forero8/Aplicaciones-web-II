import os;
os.system("cls")

cantidad_llantas = int(input("¿Cuántas llantas deseas comprar?: "))

if cantidad_llantas < 5:
    precio_unitario = 30000
elif cantidad_llantas <= 10:
    precio_unitario = 25000
else:
    precio_unitario = 20000

total_pagar = cantidad_llantas * precio_unitario

print("\nResumen de la compra")
print(f"Cantidad de llantas: {cantidad_llantas}")
print(f"Precio unitario: ${precio_unitario:,.0f}")
print(f"Total a pagar: ${total_pagar:,.0f}")
