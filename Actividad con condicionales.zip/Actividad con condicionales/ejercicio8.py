import os;
os.system("cls")   

dia = int(input("Ingresa el día: "))
mes = int(input("Ingresa el mes: "))
anio = int(input("Ingresa el año: "))

dia_original = dia
mes_original = mes
anio_original = anio

dia += 1

if dia > 30:
    dia = 1
    mes += 1
    
    if mes > 12:
        mes = 1
        anio += 1

print(f"La fecha siguiente a {dia_original}/{mes_original}/{anio_original} es {dia}/{mes}/{anio}")
