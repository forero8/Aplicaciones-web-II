import os;
os.system("cls")

numero = float(input("Pon el numero mi pelao: "))

if numero > 0:
    print(f"El número {numero} es positivo mi pelao")
elif numero < 0:
    print(f"El número {numero} es negativo mi pelao")
else:
    print(f"El número {numero} es cero")
