TARIFAS_BARRIOS = {
    "torices": {"distancia": 15, "costo": 25000},
    "bicentenario": {"distancia": 30, "costo": 70000},
    "marbella": {"distancia": 10, "costo": 10000}
}

def calcular_total(base, *valores, **kwargs):
    iva = kwargs.get("iva", 0.19)
    domicilio = kwargs.get("domicilio", 0)

    subtotal = base + sum(valores)
    total_con_iva = subtotal * (1 + iva)
    total_final = total_con_iva + domicilio

    return total_final


if __name__ == "__main__":
    base = float(input("Valor base del producto: "))
    
    print("\nBarrios disponibles:")
    for barrio in TARIFAS_BARRIOS:
        tarifa = TARIFAS_BARRIOS[barrio]
        print(f"  - {barrio}: ${tarifa['costo']} (distancia: {tarifa['distancia']} km)")
    
    barrio = input("\nIngresa el barrio: ").lower()
    
    if barrio not in TARIFAS_BARRIOS:
        print("Barrio no encontrado")
    else:
        domicilio = TARIFAS_BARRIOS[barrio]["costo"]
        
        resultado = calcular_total(
            base,
            iva=0.19,
            domicilio=domicilio
        )

        print(f"\nTotal a pagar: ${resultado}")
