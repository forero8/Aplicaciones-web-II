def asignar_repartidor(pedido, *repartidores):

    if not repartidores:
        return "No hay repartidores disponibles"

    return {
        "pedido": pedido,
        "repartidor_asignado": repartidores[0]
    }


TARIFAS_BARRIOS = {
    "torices": {"distancia": 15, "costo": 25000},
    "bicentenario": {"distancia": 30, "costo": 70000},
    "marbella": {"distancia": 10, "costo": 10000}
}

REPARTIDORES_BASE = {
    "rep01": {"nombre": "Juan Pérez", "disponible": True},
    "rep02": {"nombre": "Carlos Gómez", "disponible": True},
    "rep03": {"nombre": "Miguel López", "disponible": True},
    "rep04": {"nombre": "David García", "disponible": True},
    "rep05": {"nombre": "Fernando Ruiz", "disponible": True}
}


if __name__ == "__main__":
    print("\nASIGNACIÓN DE REPARTIDORES")
    
    print("\nBarrios disponibles:")
    for barrio in TARIFAS_BARRIOS:
        tarifa = TARIFAS_BARRIOS[barrio]
        print(f"  - {barrio}: ${tarifa['costo']} (distancia: {tarifa['distancia']} km)")
    
    destino = input("\nDestino del pedido: ").lower()
    
    if destino not in TARIFAS_BARRIOS:
        print("Barrio no encontrado")
    else:
        costo = TARIFAS_BARRIOS[destino]["costo"]
        
        print("\nRepartidores disponibles:")
        repartidores_disponibles = []
        for repo_id, repo_info in REPARTIDORES_BASE.items():
            if repo_info["disponible"]:
                repartidores_disponibles.append(repo_id)
                print(f"  {repo_id}: {repo_info['nombre']}")
        
        if not repartidores_disponibles:
            print("No hay repartidores disponibles")
        else:
            repo_id = repartidores_disponibles[0]
            repartidor = REPARTIDORES_BASE[repo_id]["nombre"]
            
            pedido = {
                "destino": destino,
                "costo": costo
            }

            resultado = asignar_repartidor(pedido, repartidor)

            print(f"\nASIGNACIÓN COMPLETADA ")
            print(f"Destino: {resultado['pedido']['destino']}")
            print(f"Costo: ${resultado['pedido']['costo']}")
            print(f"Repartidor asignado: {resultado['repartidor_asignado']}")
