DESTINOS = {
    "torices": {"distancia": 15, "costo": 25000},
    "bicentenario": {"distancia": 30, "costo": 70000},
    "marbella": {"distancia": 10, "costo": 10000}
}

def calcular_ruta(destino, *args, **kwargs):

    destino = destino.lower()

    if destino not in DESTINOS:
        return "Destino no valido"

    datos = DESTINOS[destino]
    costo = datos["costo"]
    distancia = datos["distancia"]

    if kwargs["ida_y_vuelta"]:
        costo *= 2
        distancia *= 2

    return {
        "destino": destino,
        "distancia_total": distancia,
        "costo_total": costo,
        "extras": args
    }


if __name__ == "__main__":
    destino = input("Destino (torices, bicentenario, marbella): ")
    ida_vuelta = input("Ida y vuelta (si/no): ")

    ida_vuelta = True if ida_vuelta.lower() == "si" else False

    ruta = calcular_ruta(
        destino,
        "Solicitud directa",
        ida_y_vuelta=ida_vuelta
    )

    print(ruta)
