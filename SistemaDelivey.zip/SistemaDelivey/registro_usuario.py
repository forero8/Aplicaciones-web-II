def registrar_usuario(*args, **kwargs):
    usuario = {
        "nombre": kwargs["nombre"],
        "telefono": kwargs["telefono"],
        "direccion": kwargs["direccion"],
        "extras": args
    }
    return usuario


if __name__ == "__main__":
    nombre = input("Nombre: ")
    telefono = input("Telefono: ")
    direccion = input("Direccion: ")
    nota = input("Nota adicional: ")

    usuario = registrar_usuario(
        nota,
        nombre=nombre,
        telefono=telefono,
        direccion=direccion
    )

    print(usuario)
